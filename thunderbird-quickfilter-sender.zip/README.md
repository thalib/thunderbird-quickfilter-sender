# thunderbird-quickfilter-sender
Thunderbird Exterion to add Quick Filter Context Menu by Devnodes.in


# Reference

* http://udn.realityripple.com/docs/Mozilla/Thunderbird/Thunderbird_extensions/Building_a_Thunderbird_extension_3:_install_manifest
